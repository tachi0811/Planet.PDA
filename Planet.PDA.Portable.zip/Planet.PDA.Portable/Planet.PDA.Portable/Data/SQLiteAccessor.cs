﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SQLite.Net;
using Xamarin.Forms;

namespace Planet.PDA.Portable
{
    public class SQLiteAccessor
    {
        static readonly object Locker = new object();
        readonly SQLiteConnection DB;


        public SQLiteAccessor()
        {
            DB = DependencyService.Get<ISQLite>().GetConnection();

            // テーブル作成
            DB.CreateTable<ap_system_parameter>();

        }

        public IEnumerable<T> GetData<T>()
            where T : class
        {
            lock(Locker)
            {
                return DB.Table<T>();
            }
        }

        public int Update<T>(T data)
            where T : class
        {
            lock(Locker)
            {
                return DB.Update(data);
            }
        }

        public int Insert<T>(T data)
            where T : class
        {
            lock(Locker)
            {
                return DB.Insert(data);
            }
        }

        public int InsertAll<T>(IEnumerable<T> dataList)
            where T : class
        {
            lock(Locker)
            {
                DB.DeleteAll<T>();
                return DB.InsertAll(dataList, true);
            }
        }

    }
}
