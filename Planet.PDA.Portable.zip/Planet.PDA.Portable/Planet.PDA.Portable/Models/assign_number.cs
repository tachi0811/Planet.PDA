using System;

namespace Planet.PDA.Portable
{
    public class assign_number
    {
        public string store_cd { get; set; }
        public string assign_year { get; set; }
        public string assign_month { get; set; }
        public string transfer_ask_no { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
