using System;

namespace Planet.PDA.Portable
{
    public class pack_weight
    {
        public string pack_weight_cd { get; set; }
        public string pack_kg { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
