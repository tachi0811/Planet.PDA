using System;

namespace Planet.PDA.Portable
{
    public class general
    {
        public string general_cd { get; set; }
        public string store_cd { get; set; }
        public string general_nm { get; set; }
        public string display_content { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
