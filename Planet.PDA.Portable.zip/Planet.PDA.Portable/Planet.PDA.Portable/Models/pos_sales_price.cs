using System;

namespace Planet.PDA.Portable
{
    public class pos_sales_price
    {
        public short pos_sales_price_cd { get; set; }
        public string user_l_name { get; set; }
        public Nullable<DateTime> create_date { get; set; }
        public Nullable<DateTime> update_date { get; set; }
    }
}
