using System;

namespace Planet.PDA.Portable
{
    public class store_delivery_trader
    {
        public string store_cd { get; set; }
        public string trader_cd { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
