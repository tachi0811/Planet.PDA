using System;

namespace Planet.PDA.Portable
{
    public class maker_brand
    {
        public string maker_cd { get; set; }
        public string brand_cd { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
