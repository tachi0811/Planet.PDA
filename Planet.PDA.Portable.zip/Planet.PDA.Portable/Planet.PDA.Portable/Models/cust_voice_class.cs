using System;

namespace Planet.PDA.Portable
{
    public class cust_voice_class
    {
        public string cust_voice_class_cd { get; set; }
        public string cust_voice_class_nm { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
