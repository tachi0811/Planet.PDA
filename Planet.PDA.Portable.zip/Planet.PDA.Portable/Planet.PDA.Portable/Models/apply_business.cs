using System;

namespace Planet.PDA.Portable
{
    public class apply_business
    {
        public string apply_business_cd { get; set; }
        public string apply_business_nm { get; set; }
        public Nullable<short> delete_flg { get; set; }
    }
}
