using System;

namespace Planet.PDA.Portable
{
    public class stocktaking_account
    {
        public string store_cd { get; set; }
        public int terminal_id { get; set; }
        public DateTime tana_account_dtetim { get; set; }
        public string staff_cd { get; set; }
    }
}
