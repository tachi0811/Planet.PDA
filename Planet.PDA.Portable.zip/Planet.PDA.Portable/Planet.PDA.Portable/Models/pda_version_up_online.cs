using System;

namespace Planet.PDA.Portable
{
    public class pda_version_up_online
    {
        public short com_kbn { get; set; }
        public Nullable<DateTime> success_com_dtetim { get; set; }
        public Nullable<DateTime> create_dte { get; set; }
        public Nullable<DateTime> update_dte { get; set; }
    }
}
