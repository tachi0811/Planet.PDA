using System;

namespace Planet.PDA.Portable
{
    public class readings0
    {
        public DateTime ReadingDate { get; set; }
        public string City { get; set; }
        public Nullable<float> HiTemp_Far { get; set; }
    }
}
