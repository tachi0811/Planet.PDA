using System;

namespace Planet.PDA.Portable
{
    public class temp
    {
        public string temp_cd { get; set; }
        public string temp_nm { get; set; }
        public Nullable<short> delete_flg { get; set; }
        public string staff_cd { get; set; }
    }
}
