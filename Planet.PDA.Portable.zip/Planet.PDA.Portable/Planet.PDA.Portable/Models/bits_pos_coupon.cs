using System;

namespace Planet.PDA.Portable
{
    public class bits_pos_coupon
    {
        public string bits_pos_payment_cd { get; set; }
        public string bits_pos_coupon_cd { get; set; }
        public string l_name { get; set; }
        public string fiscalstamp_target_flg { get; set; }
        public Nullable<DateTime> create_date { get; set; }
        public Nullable<DateTime> update_date { get; set; }
    }
}
